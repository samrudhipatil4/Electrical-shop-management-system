<?php 
   include("db.php");
   $Id=$_GET['Id'];
   echo $Id;
    $sql="delete from empregistration where Id='$Id'";
    $result=mysqli_query($conn,$sql);
    if($result)
    {
      header('location:manage_emp.php');
    }
   ?>