<?php 
   include("db.php");
    
   ?>
<!DOCTYPE html>
<html>
<head>
	<title>bill manage</title>
	<link rel="stylesheet" href="css/manage_emp.css" />
	<style>
		.delete_A
{
	color: green;
	font-weight: bold;

}
	</style>
</head>
<body>
	<center><h1>GENARETE EMPLOYEE SALARY RECIPT</h1>
	<table id="customers">

		<tr>
			<th>ID</th>
			<th>NAME</th>
			<th>Mobile NO</th>
			<th>Email</th>
			<th>Gender</th>
			<th>Birth Date</th>
			<th>Aadhanr No</th>
			<th>Pan NO</th>
			<th>Address</th>
			<th>Qualification</th>
			<th>salary</th>
			<th>Accont NO</th>
			<th>Join Date</th>
			<th>Genarete Recipt</th>
		</tr>
		<?php 
       $sql = "SELECT * FROM empregistration";
       $query = mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($query))
       {
       ?>
		<tr>
			<td><?php echo $row['Id'] ?></td>
			<td><?php echo $row['Name'] ?></td>
			<td><?php echo $row['Mobile_No'] ?></td>
			<td><?php echo $row['Email'] ?></td>
			<td><?php echo $row['Gender'] ?></td>
			<td><?php echo $row['Data_Birth'] ?></td>
			<td><?php echo $row['Aadhar_No'] ?></td>
			<td><?php echo $row['PAN_NO'] ?></td>
			<td><?php echo $row['Address'] ?></td>
			<td><?php echo $row['Qualification'] ?></td>
			<td><?php echo $row['Salary'] ?></td>
			<td><?php echo $row['Account_No'] ?></td>
			<td><?php echo $row['Join_Date'] ?></td>

			<td>
				<a class="delete_A" href="genarete_salary_recipt.php?Id=<?php echo $row['Id'] ?>">Genarete Receipt</a>
			</td>
		</tr>
		<?php 
	    }
	?>
	</table></center>
</body>
</html>