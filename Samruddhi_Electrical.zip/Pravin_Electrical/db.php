<?php 
$host = "localhost";  
    $user = "root";  
    $password = '';  
    $db_name = "pravin_electrical"; 

    $conn = mysqli_connect("localhost", "root","","pravin_electrical");
    if(mysqli_connect_errno())
    {
    	echo "failed to connect to mysql" .mysql_connect_errno();
    	exit();
    }
?>