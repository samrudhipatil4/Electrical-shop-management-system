<?php
		$conn = mysqli_connect("localhost", "root", "", "pravin_electrical");
	if(!$conn)
	{
		echo "Connection Failed ".$mysqli_connect_error();
	}
	if ($_POST["button"])
	{
		$id = $_POST["id"];
		$Product_Name = $_POST["Product_Name"];
		$Price = $_POST["Price"];
		$QYT = $_POST["QYT"];
		$sql = "insert into product(id,product_name,product_price,product_qty ) values('$id',
		'$Product_Name','$Price','$QYT')";
		$result=mysqli_query($conn,$sql);
		if($result)
		{
			echo "Record save";
			header('location:home_page.php');
		}
		else
		{
			echo "Record not save";
		}
     }
	?>