<?php
		$conn = mysqli_connect("localhost", "root", "", "pravin_electrical");
	if(!$conn)
	{
		echo "Connection Failed ".$mysqli_connect_error();
	}
	if ($_POST["button"])
	{
		$id = $_POST["id"];
		$Product_Name = $_POST["Product_Name"];
		$Price = $_POST["Price"];
		$QYT = $_POST["QYT"];
		$Price = $_POST["Price"];
		$sql = "UPDATE product SET product_name='$Product_Name',product_price='$Price',product_qty='$QYT' where id='$id'";
		$result=mysqli_query($conn,$sql);
		if($result)
		{
			echo "Record UPDATE";
			header('location:home_page.php');
		}
		else
		{
			echo "Record not UPDATE";
		}
     }
     mysqli_close($conn);
	?>


	