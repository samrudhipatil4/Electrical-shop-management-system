<?php
include("db.php");
$id=$_GET['id'];
       $sql = "SELECT * FROM product where Id=$id";
       $query = mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($query))
{
  $Product_Name = $row["product_name"];
  $Price = $row["product_price"];
  $QYT = $row["product_qty"];
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> update page</title>
    <link rel="stylesheet" href="css/Billiteam_insert.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="title">Update Product</div>
    <div class="content">
      <form action="bill_update.php" method="POST">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Product ID</span>
          <input type="text" name="id" value="<?php echo $id ?>">
          </div>
          <div class="input-box">
            <span class="details">Product Name</span>
            <input type="text" name="Product_Name"  value="<?php echo $Product_Name ?>">
          </div>
          <div class="input-box" >
            <span class="details">Product Price</span>
            <input type="text" name="Price" value="<?php echo $Price ?>">
          </div>
          <div class="input-box">
            <span class="details">Product Quantity</span>
            <input type="text" name="QYT" value="<?php echo $QYT ?>">
          </div>
          
        </div>
        <div class="button">
          <input type="submit" name="button" value="Update Product">
        </div>
      </form>
    </div>
  </div>
?>
</body>
</html>


