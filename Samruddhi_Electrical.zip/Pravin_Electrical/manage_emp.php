<?php 
   include("db.php");
    
   ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Bill Manage</title>
	<link rel="stylesheet" href="css/manage_product.css" />
</head>
<body>
	<center><h1>PRAVIN ELECTRICAL EMPLOYEE PROFILE</h1>
	<table id="customers">

		<tr>
			<th>ID</th>
			<th>NAME</th>
			<th>Mobile NO</th>
			<th>Email</th>
			<th>Gender</th>
			<th>Birth Date</th>
			<th>Aadhanr No</th>
			<th>Pan NO</th>
			<th>Address</th>
			<th>Qualification</th>
			<th>salary</th>
			<th>Accont NO</th>
			<th>Join Date</th>
			<th>Delete</th>
			<th>Update</th>
		</tr>
		<?php 
       $sql = "SELECT * FROM empregistration";
       $query = mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($query))
       {
       ?>
		<tr>
			<td><?php echo $row['Id'] ?></td>
			<td><?php echo $row['Name'] ?></td>
			<td><?php echo $row['Mobile_No'] ?></td>
			<td><?php echo $row['Email'] ?></td>
			<td><?php echo $row['Gender'] ?></td>
			<td><?php echo $row['Data_Birth'] ?></td>
			<td><?php echo $row['Aadhar_No'] ?></td>
			<td><?php echo $row['PAN_NO'] ?></td>
			<td><?php echo $row['Address'] ?></td>
			<td><?php echo $row['Qualification'] ?></td>
			<td><?php echo $row['Salary'] ?></td>
			<td><?php echo $row['Account_No'] ?></td>
			<td><?php echo $row['Join_Date'] ?></td>

			<td>
				<a class="delete_A" href="action_delete_Emp.php?Id=<?php echo $row['Id'] ?>">Delete</a>
			</td>
			<td>
				<a class="Update_A" href="update_emp.php?Id=<?php echo $row['Id'] ?>">Update</a>
			</td>
		</tr>
		<?php 
	    }
	?>
	</table></center>
</body>
</html>