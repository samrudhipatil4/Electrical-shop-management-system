<?php
	$conn = mysqli_connect("localhost", "root", "", "pravin_electrical");
	if(!$conn)
	{
		echo "Connection Failed ".$mysqli_connect_error();
	}
	if ($_POST["btn"])
	{
		$id=$_POST['id'];
		$fname=$_POST['name'];
		$mobile_no=$_POST['mobile_no'];
		$aadhar_no=$_POST['aadhar_no'];
		$salary=$_POST['salary'];
		$account_no=$_POST['account_no'];
		

		$Sql="insert into emp_salary (id, name, mobile, aadhar_no,salary,account_no) 
		values('$id','$fname' , '$mobile_no', '$aadhar_no','$salary' ,'$account_no')";
		$result=mysqli_query($conn,$Sql);
		if($result)
		{
			echo "record save";
			header('location:emp_salary_view.php');
		}
		else
		{
			echo "record not save";
		}

	}
?>