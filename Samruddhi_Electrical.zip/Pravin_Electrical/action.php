<?php
  session_start();
$servername = "localhost";
$dBUsername = "root";
$dbPassword = "";
$dBName = "pravin_electrical";

$conn = mysqli_connect($servername, $dBUsername, $dbPassword, $dBName);

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM admin_login";
$result = $conn->query($sql);

while($row = $result->fetch_assoc()) {
        if(($username == $row["username"]) && ($password == $row["password"]))
			{
			$_SESSION['adminuser'] = $username;
			header('location:home_page.php');
			}
		else
			{
			header('location:index.php?err='.urlencode('Username Or Password Incorrect'));
			}
    }	
?>
?>