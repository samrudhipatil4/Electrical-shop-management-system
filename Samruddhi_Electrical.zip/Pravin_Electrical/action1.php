<?php 
   include("db.php");
   $id=$_GET['id'];
   echo $id;
    $sql="delete from product where id='$id'";
    $result=mysqli_query($conn,$sql);
    if($result)
    {
      header('location:manage_product.php');
    }
   ?>