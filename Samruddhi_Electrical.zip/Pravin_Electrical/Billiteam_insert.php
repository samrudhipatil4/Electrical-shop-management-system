<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Insert Product</title>
    <link rel="stylesheet" href="css/Billiteam_insert.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="container">
    <div class="title">Add New Iteam</div>
    <div class="content">
      <form action="Billiteam_insert_save.php" method="POST">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Product ID</span>
            <input type="text" name="id" placeholder="Enter ID Number" required>
          </div>
          <div class="input-box">
            <span class="details">Product Name</span>
            <input type="text" name="Product_Name" placeholder="Enter Product Name" required>
          </div>
          <div class="input-box">
            <span class="details">Product Price</span>
            <input type="text" name="Price" placeholder="Enter Price" required>
          </div>
          <div class="input-box">
            <span class="details">Product Quantity</span>
            <input type="text" name="QYT" placeholder="Enter Quantity" required>
          </div>
          
        </div>
        <div class="button">
          <input type="submit" name="button" value="Add New Product">
        </div>
      </form>
    </div>
  </div>

</body>
</html>


