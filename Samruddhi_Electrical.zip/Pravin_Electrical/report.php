<?php 
   include("db.php");
    
   ?>
<!DOCTYPE html>
<html>
<head>
    <title>Report Generation</title>
    <link rel="stylesheet" type="text/css" href="css/report.css">
    <style type="text/css">
        #customers 
{
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
  padding-left: 100px;
  margin-right: 100px;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 5px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #336895;
  color: white;
}
.Update_A
{
    color: green;
    font-weight: bold;

}
.delete_A
{
    color: red;
    font-weight: bold;
}
    </style>
</head>
<body>
    <h1>Report Generation</h1>

    <form method="post" action="">
        <label for="start_date">Start Date:</label>
        <input type="date" name="start_date" id="start_date" required>
        <label for="end_date">End Date:</label>
        <input type="date" name="end_date" id="end_date" required>
        <input class="repor" name="btn"type="submit" value="Generate Report">
    </form>
    <br><BR><BR>
<center><h1> EMPLOYEE REPORT </h1>
    <table id="customers">

        <tr>
            <th>ID</th>
            
        
            <th>NAME</th>
            
    
            <th>Mobile NO</th>  
            
            <th>Aadhanr No</th>
                
            
            
        
            <th>Accont NO</th>
            <th>Date</th>

            <th>salary</th>
            
        </tr>
            <?php 
            if(isset($_POST['btn']))
            {
                
                $start_date=$_POST['start_date'];
                $end_date=$_POST['end_date'];
                $sql1 = "SELECT sum(salary) FROM emp_salary WHERE rdata BETWEEN  '$start_date' AND '$end_date'";
       $query1 = mysqli_query($conn,$sql1);
       while($row1 = mysqli_fetch_assoc($query1))
       {
        $total=$row1['sum(salary)'] ;
       }
       $sql = "SELECT * FROM emp_salary WHERE rdata BETWEEN  '$start_date' AND '$end_date'";
       $query = mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($query))
       {
       ?>
        <tr>
            <td><?php echo $row['id'] ?></td>
            <td><?php echo $row['name'] ?></td>
            <td><?php echo $row['mobile'] ?></td>
            <td><?php echo $row['aadhar_no'] ?></td>
            
            <td><?php echo $row['account_no'] ?></td>
            <td><?php echo $row['rdata'] ?></td>
            <td><?php echo $row['salary'] ?></td>
          
        </tr>
    <?php } }
            if(!isset($_POST['btn']))
            {
                
        $sql1 = "SELECT sum(salary) FROM emp_salary";
       $query1 = mysqli_query($conn,$sql1);
       while($row1 = mysqli_fetch_assoc($query1))
       {
        $total=$row1['sum(salary)'] ;
       }
       $sql = "SELECT * FROM emp_salary";
       $query = mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($query))
       {
       ?>
        <tr>
            <td><?php echo $row['id'] ?></td>
            <td><?php echo $row['name'] ?></td>
            <td><?php echo $row['mobile'] ?></td>
            <td><?php echo $row['aadhar_no'] ?></td> 
            <td><?php echo $row['account_no'] ?></td>
            <td><?php echo $row['rdata'] ?></td>
            <td><?php echo $row['salary'] ?></td>
          
        </tr>
    <?php  } }

    ?>

    <tr>
        <td colspan="6"><center><b>Total</b></center></td>
        <td><center><b><?php echo $total?></b></center></td>
    </tr>
            </table>
    </center>
        
</body>
</html>

