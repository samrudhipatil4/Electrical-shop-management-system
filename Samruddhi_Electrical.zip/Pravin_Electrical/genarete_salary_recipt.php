<?php 
   include("db.php");
    
   ?>
<!DOCTYPE html>
<html>
<head>
	<title>bill manage</title>
	<link rel="stylesheet" href="css/genarete_salary_recipt.css" />
	<style>
		.delete_A
{
	color: green;
	font-weight: bold;

}
	</style>
</head>
<body>
	<form action="save_reciptdata.php" method="POST">
			
		</tr>
		<?php 
		$id=$_GET['Id'];
       $sql = "SELECT * FROM empregistration where id=$id";
       $query = mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($query))
       {
       ?>
		<center><h2>PRAVIN ELECTRICAL SALARY RECEIPT</h2>
	<table id="customers">

		<tr>
			<th>ID</th>
			<td><?php echo $row['Id'] ?></td>
		</tr>
		<tr>
			<th>NAME</th>
			<td><?php echo $row['Name'] ?></td>
		</tr>
		<tr>
			<th>Mobile NO</th>	
			<td><?php echo $row['Mobile_No'] ?></td>
		</tr>
		<tr>
			<th>Aadhanr No</th>
				<td><?php echo $row['Aadhar_No'] ?></td>
		</tr>
		<tr>	
			<th>salary</th>
			<td><?php echo $row['Salary'] ?></td>
		</tr>
		<tr>
			<th>Accont NO</th>
				<td><?php echo $row['Account_No'] ?></td>
		</tr>
			</table>
	</center>
	 <input type="text" name="id" value="<?php echo $row['Id'] ?>" hidden>
	  <input type="text" name="name" value="<?php echo $row['Name'] ?>" hidden>
	  <input type="text" name="mobile_no" value="<?php echo $row['Mobile_No'] ?>" hidden> 
	  <input type="text" name="aadhar_no" value="<?php echo $row['Aadhar_No'] ?>" hidden>
	  <input type="text" name="salary" value="<?php echo $row['Salary'] ?>" hidden>
	  <input type="text" name="account_no" value="<?php echo $row['Account_No'] ?>" hidden>
	 <input class="rep" type="submit" value="Print" name="btn" onclick="printWindow()">
	 </form>

		<?php 
	    }
		?>
	
	 
	  
	  <script>
	  	function printWindow() 
	  	{
    			window.print();
		}
	  </script>
</body>
</html>