<?php 
   include("db.php");
    
   ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>bill manage</title>
	<link rel="stylesheet" href="css/manage_product.css">
</head>
<body>
	<center><h1>BILL PRODUCT DELETE AND UPDATE</h1>
	<table id="customers">

		<tr>
			<th>ID</th>
			<th>NAME</th>
			<th>PRICE</th>
			<th>DELETE ACTION</th>
			<th>UPDATE ACTION</th>
		</tr>
		<?php 
       $sql = "SELECT * FROM product";
       $query = mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($query))
       {
       ?>
		<tr>
			<td><?php echo $row['id'] ?></td>
			<td><?php echo $row['product_name'] ?></td>
			<td><?php echo $row['product_price'] ?></td>
			<td>
				<a class="delete_A" href="action1.php?id=<?php echo $row['id'] ?>">Delete</a>
			</td>
			<td>
				<a class="Update_A" href="Billiteam_update.php?id=<?php echo $row['id'] ?>">Update</a>
			</td>
		</tr>
		<?php 
	    }
	?>
	</table></center>
</body>
</html>