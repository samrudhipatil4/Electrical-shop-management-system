<?php
	$conn = mysqli_connect("localhost", "root", "", "pravin_electrical");
	if(!$conn)
	{
		echo "Connection Failed ".$mysqli_connect_error();
	}
	if ($_POST["btn"])
	{
		$fname=$_POST["fname"];
		$mobile_no=$_POST["mobile_no"];
		$email=$_POST["email"];
		$gender=$_POST["gender"];
		$date_birth=$_POST["date_birth"];
		$aadhar_no=$_POST["aadhar_no"];
		$pan=$_POST["pan"];
		$address=$_POST["address"];
		$qualification=$_POST["qualification"];
		$salary=$_POST["salary"];
		$account_no=$_POST["account_no"];
		$join_date=$_POST["join_date"];
		

		$Sql="insert into empregistration(Name,Mobile_No,Email,Gender,Data_Birth,Aadhar_No,PAN_NO, Address,Qualification,Salary,Account_No,Join_Date) 
		values('$fname' , '$mobile_no' ,'$email' ,'$gender' ,'$date_birth' ,'$aadhar_no' ,
		'$pan', '$address' ,'$qualification' ,'$salary' ,'$account_no' ,'$join_date')";
		$result=mysqli_query($conn,$Sql);
		if($result)
		{
			echo "record save";
			header('location:home_page.php');
		}
		else
		{
			echo "record not save";
		}

	}
?>