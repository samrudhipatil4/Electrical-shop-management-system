<?php
	$conn = mysqli_connect("localhost", "root", "", "pravin_electrical");
	if(!$conn)
	{
		echo "Connection Failed ".$mysqli_connect_error();
	}
	if ($_POST["button"])
	{
		$Id = $_POST["id"];
		$fname=$_POST["fname"];
		$mobile_no=$_POST["mobile_no"];
		$email=$_POST["email"];
		$gender=$_POST["gender"];
		$date_birth=$_POST["date_birth"];
		$aadhar_no=$_POST["aadhar_no"];
		$pan=$_POST["pan"];
		$address=$_POST["address"];
		$qualification=$_POST["qualification"];
		$salary=$_POST["salary"];
		$account_no=$_POST["account_no"];
		$join_date=$_POST["join_date"];

		

		$Sql=" UPDATE  empregistration SET Name='$fname', Mobile_No='$mobile_no',Email='$email',Gender='$gender',Data_Birth='$date_birth',Aadhar_No=$aadhar_no,PAN_NO='$pan', Address='$address',Qualification='$qualification',Salary=$salary,Account_No=$account_no,Join_Date='$join_date'where Id='$Id'";
		$result=mysqli_query($conn,$Sql);
		if($result)
		{
			echo "record save";
			header('location:home_page.php');
		}
		else
		{
			echo "record not save";
		}

	}
?>