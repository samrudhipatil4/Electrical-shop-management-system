<?php
session_start();
if(isset($_SESSION['adminuser']))
  {
  
  }
  else
  {
    header('location:index.php');
  }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Welcome Pravin Electrical</title>
    <link rel="stylesheet" href="css/home_page.css">
    <script src=""></script>
   </head>
<body>
  <nav>
      <div class="menu">
        <div class="logo">
          <a href="#">Pravin Electrical Nashik</a>
        </div>
          <ul>
            <li><a href="Registration.php">Add Employee</a></li>
            <li><a href="manage_emp.php">Emp Profile</a></li>
            <li><a href="emp_salary_view.php">Employee salary</a></li>
                <li> <select name="slct" id="slct" onchange="redirectToPage()">
                <option>Manage Product</option>
                <option value="Billiteam_insert.php">Add Product</option>
                <option value="manage_product.php">Update Delete</option>
                
            </select></li>  
            <li><a href="billing.php">Customer Bill</a></li>
            <li> <select name="slct" id="slct1" onchange="redirectToPage1()">
                <option>Report</option>
                <option value="report.php">Employee</option>
                <option value="customer_report.php">Customer</option>
                
            </select></li>
 
            <li><a href="logout.php">Logout</a></li> 
          </ul>
      </div>
  </nav>

<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 12</div>
  <img src="img/e11.jpg" style="width:100%" height="50%">
  <div class="text"></div>
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 12</div>
  <img src="img/e12.jpg" style="width:100%" height="50%">
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 12</div>
  <img src="img/i20.jpg" style="width:100%" height="50%">
</div>
<div class="mySlides fade">
  <div class="numbertext">4 / 12</div>
  <img src="img/i18.jpg" style="width:100%" height="50%">
</div>
<div class="mySlides fade">
  <div class="numbertext">5 / 12</div>
  <img src="img/e11.jpg" style="width:100%" height="50%">
</div>
<div class="mySlides fade">
  <div class="numbertext">6 / 12</div>
  <img src="img/i5.jpeg" style="width:100%" height="50%">
</div>
<div class="mySlides fade">
  <div class="numbertext">7 / 12</div>
  <img src="img/i6.jpeg" style="width:100%" height="50%">
</div>
<div class="mySlides fade">
  <div class="numbertext">8 / 12</div>
  <img src="img/i7.jpeg" style="width:100%" height="50%">
</div>
<div class="mySlides fade">
  <div class="numbertext">9 / 12</div>
  <img src="img/i2.jpeg" style="width:100%" height="50%">
</div>
<div class="mySlides fade">
  <div class="numbertext">10 / 12</div>
  <img src="img/i4.jpeg" style="width:100%" height="50%">
</div>
<div class="mySlides fade">
  <div class="numbertext">11 / 12</div>
  <img src="img/i10.jpeg" style="width:100%" height="50%">
</div>
<div class="mySlides fade">
  <div class="numbertext">12 / 12</div>
  <img src="img/i12.jpeg" style="width:100%" height="50%">
</div>

<br>

<div style="text-align:center">
  <span class="dot"></span> 
  <span class="dot"></span> 
  <span class="dot"></span>
   <span class="dot"></span> 
    <span class="dot"></span> 
     <span class="dot"></span> 
      <span class="dot"></span> 
       <span class="dot"></span>
        <span class="dot"></span> 
         <span class="dot"></span> 
          <span class="dot"></span> 

</div>

<script>
let slideIndex = 0;
showSlides();

function showSlides() {
  let i;
  let slides = document.getElementsByClassName("mySlides");
  let dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";  
  dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 3000); 
}


    function redirectToPage() 
    {
      var selectElement = document.getElementById("slct");
      var selectedOption = selectElement.value;
      window.location.href = selectedOption;
    }
      function redirectToPage1() 
    {
      var selectElement = document.getElementById("slct1");
      var selectedOption = selectElement.value;
      window.location.href = selectedOption;
    }
  
</script
</body>

</html>
