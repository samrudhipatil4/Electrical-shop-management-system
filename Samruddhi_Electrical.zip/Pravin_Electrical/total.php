<?php
   $conn = mysqli_connect("localhost", "root", "", "pravin_electrical");
   if(!$conn)
   {
      echo "Connection Failed ".$mysqli_connect_error();
   }
   if ($_POST["btn"])
   {
        $total=$_POST['total'];
        $sql = "insert into customer_report(total)values($total)";
      
      $result=mysqli_query($conn,$sql);
      if($result)
      {
         echo "Record Save Successfully";
       
        
      }
      else
      {
         echo "record not save";
      }

   }
?>