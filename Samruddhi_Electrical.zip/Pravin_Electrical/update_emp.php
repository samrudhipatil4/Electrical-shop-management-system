<?php 
include("db.php");
$id=$_GET['Id'];
       $sql = "SELECT * FROM empregistration where Id=$id";
       $query = mysqli_query($conn,$sql);
       while($row = mysqli_fetch_assoc($query))
       {
        $fname=$row["Name"];
        $mobile_no=$row["Mobile_No"];
        $email=$row["Email"];
        $gender=$row["Gender"];
        $date_birth=$row["Data_Birth"];
        $aadhar_no=$row["Aadhar_No"];
        $pan=$row["PAN_NO"];
        $address=$row["Address"];
        $qualification=$row["Qualification"];
        $salary=$row["Salary"];
        $account_no=$row["Account_No"];
        $join_date=$row["Join_Date"];
       }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/style.css">
    <title>update Form </title> 
</head>
<style>
    .btn
    {
        width: 150px;
        height: 30px;
        margin-top: 30px;
        margin-left: 350px;
        background-color: #4CAF50;
        font-weight: bold;
        color: white;
        border: none;
    }
</style>
<body>
    <div class="container">
        <header>Update</header>

        <form action="update_emp_php.php" method="POST">
            <div class="form first">
                <div class="details personal">
                    <span class="title">Personal Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Full Name</label>
                            <input type="hidden" name="id" value="<?php echo $id ?>" >
                            <input type="text" value="<?php echo $fname ?>" name="fname" placeholder="Enter your name" required>
                        </div>

                        <div class="input-field">
                            <label>Mobile No</label>
                            <input type="number"value="<?php echo $mobile_no ?>" name="mobile_no" placeholder="Enter Mobile Number" required>
                        </div>

                        <div class="input-field">
                            <label>Email</label>
                            <input type="text" value="<?php echo  $email ?>" name="email" placeholder="Enter your email" required>
                        </div>

                        <div class="input-field">
                            <label>Birth Date</label>
                            <input type="date" value="<?php echo  $date_birth ?>" name="date_birth" placeholder="Enter Birth Day" required>
                        </div>

                        <div class="input-field">
                            <label>Gender</label>
                            <select name="gender" required>
                                <option disabled selected>Select gender</option>
                                <option selected>Male</option>
                                <option>Female</option>
                                <option>Others</option>
                            </select>
                        </div>

                        <div class="input-field">
                            <label>Aadhar No</label>
                            <input type="text" value="<?php echo  $aadhar_no ?>" name="aadhar_no" placeholder="Enter your Aadhar No" required>
                        </div>
                    </div>
                </div>

                <div class="details ID">
                   

                    <div class="fields">
                        <div class="input-field">
                            <label>PAN NO</label>
                            <input type="number" value="<?php echo $pan ?>"name="pan" placeholder="Enter PAN NO" required>
                        </div>

                        <div class="input-field">
                            <label>Address</label>
                            <input type="text" value="<?php echo  $address?>"name="address" placeholder="Enter Address" required>
                        </div>

                        <div class="input-field">
                            <label>Qualification</label>
                            <input type="text" value="<?php echo $qualification ?>"name="qualification" placeholder="Enter Qualification" required>
                        </div>

                        <div class="input-field">
                            <label>Salary</label>
                            <input type="number" value="<?php echo $salary ?>" name="salary" placeholder="Salary" required>
                        </div>

                        <div class="input-field">
                            <label>Account No</label>
                            <input type="number" value="<?php echo $account_no ?>" name="account_no" placeholder="Enter your Account No" required>
                        </div>

                        <div class="input-field">
                            <label>Join Date</label>
                            <input type="date" value="<?php echo $join_date ?>" name="join_date" placeholder="Enter Join Date" required>
                        </div>
                    </div>

                        <input type="submit"  class="btn" name="button" value="update">
                   
                </div> 
            </div>

           
        </form>
    </div>

    <script src="script.js"></script>
</body>
</html>