<?php
if(isset($_SESSION['adminuser']))
  {
  header('location:home_page.php');
  }
  else
  {
    
  }
  ?>
<!DOCTYPE html>
<html>
<head>
<title>Log In</title>
<link rel="stylesheet" href="css/admin.css" />
</head>
<body>
  <form action="action.php" method="post">
<nav><a href="#" class="focus">Pravin Electrical Nashik Log In</a></nav>
  <h2>Admin Login</h2>

  <input type="text" name="username" class="text-field" placeholder="Admin Name" />
  <input type="password" name="password" class="text-field" placeholder="Password" />
  <input class="button" type="submit" value="Log In">
</form>
</body>
</html>

